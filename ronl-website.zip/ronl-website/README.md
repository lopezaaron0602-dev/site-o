# RONL portfolio — downloadable website

A static copy of https://ronl.netlify.app/, captured November 8, 2026.

Extract the ZIP, then open index.html in a browser. Keep the assets folder and portrait image next to index.html. Fonts, styling, images, and interactive portfolio panels are included for offline use.

This archive contains the publicly served HTML, CSS, JavaScript, and assets. It does not contain the original development repository or server configuration. Contact form delivery requires the original hosting service; use the email link from this copy instead.
