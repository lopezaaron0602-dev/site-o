// Two slides: the original Home and a combined Personal information sheet.
const main = document.querySelector('main');
const about = document.querySelector('#about');
const wrap = about.querySelector(':scope > .wrap');
const grid = document.createElement('div');
grid.className = 'combined-grid';
const introduction = document.createElement('article');
introduction.className = 'about-introduction';
introduction.append(about.querySelector('.about-text'));
const character = document.createElement('article');
character.id = 'character';
character.append(about.querySelector('.about-grid').lastElementChild);
about.querySelector('.about-grid').remove();
wrap.querySelector('.eyebrow').remove();
wrap.querySelector('h2').textContent = 'Personal information';
const advancement = document.querySelector('#advancement');
const advancementGrid = advancement.querySelector('.adv-grid');
const questsPanel = document.createElement('article');
questsPanel.id = 'quests';
questsPanel.append(advancementGrid.firstElementChild);
const roadmapPanel = document.createElement('article');
roadmapPanel.id = 'roadmap';
roadmapPanel.append(advancementGrid.firstElementChild);
advancementGrid.remove();
// Retain section IDs so existing Home buttons and saved links still work.
const panels = [advancement, document.querySelector('#inventory'), document.querySelector('#contact')];
for (const panel of panels) {
  const content = panel.querySelector(':scope > .wrap');
  panel.replaceChildren(...content.childNodes);
  panel.classList.remove('section');
  panel.classList.add('combined-panel');
}
grid.append(introduction, character, advancement, questsPanel, roadmapPanel, panels[1], panels[2]);
wrap.append(grid);
// Keep all seven sections available in one accessible native popup.
const dialog = document.createElement('dialog');
dialog.className = 'content-popup';
dialog.setAttribute('aria-labelledby', 'popup-title');
dialog.innerHTML = '<header class="popup-header"><h2 id="popup-title"></h2><button type="button" class="popup-close" aria-label="Close content popup">Close <span aria-hidden="true">×</span></button></header><div class="popup-viewport"><div class="popup-content"></div></div>';
document.body.append(dialog);
const popupContent = dialog.querySelector('.popup-content');
const popupSections = new Map();
const chapterFacts = {
  biography: 'Gaming · Music · Creative ideas',
  character: 'Level 18 · BS Computer Science',
  advancement: '640 / 1000 XP · CS Apprentice',
  quests: '3 cleared · 2 active · 2 locked',
  roadmap: 'Year 1 → Future game developer',
  inventory: '12 items collected · 4 slots free',
  contact: 'Class projects · Game jams · Code'
};
const entries = [
  [introduction, 'biography', 'Hello, I’m Aaron', 'A little about me, my interests, and my goals.'],
  [character, 'character', 'Character sheet', 'Meet the player behind the portfolio.'],
  [advancement, 'advancement', 'Level up', 'My experience, skills, and next unlocks.'],
  [questsPanel, 'quests', 'Quest log', 'Completed quests and challenges ahead.'],
  [roadmapPanel, 'roadmap', 'The road map', 'My journey toward game development.'],
  [panels[1], 'inventory', 'The bag', 'Explore the skills and tools in my inventory.'],
  [panels[2], 'contact', 'Join my party', 'Get in touch and let’s make something together.']
];
entries.forEach(([section, id, title, description], index) => {
  section.id = id;
  section.hidden = true;
  section.inert = true;
  popupContent.append(section);
  const card = document.createElement('button');
  card.type = 'button';
  card.className = 'content-card';
  card.setAttribute('aria-haspopup', 'dialog');
  card.style.setProperty('--chapter-delay', `${index * 65}ms`);
  const number = document.createElement('span');
  number.className = 'card-number';
  number.textContent = String(index + 1).padStart(2, '0');
  const heading = document.createElement('span');
  heading.className = 'card-title';
  heading.textContent = title;
  const summary = document.createElement('span');
  summary.className = 'card-summary';
  summary.textContent = description;
  const arrow = document.createElement('span');
  arrow.className = 'card-open';
  arrow.textContent = 'Open ↗';
  arrow.setAttribute('aria-hidden', 'true');
  const fact = document.createElement('span');
  fact.className = 'card-fact';
  fact.textContent = chapterFacts[id];
  card.append(number, heading, summary, fact, arrow);
  if (id !== 'contact') grid.append(card);
  popupSections.set(id, { section, title, card });
  card.addEventListener('click', () => openPopup(id));
});
const hint = document.createElement('p');
hint.className = 'about-hint';
hint.textContent = 'Six chapters. One player. A journey still in progress.';
const overview = document.createElement('div');
overview.className = 'player-overview';
overview.innerHTML = '<div class="overview-story"><p class="eyebrow">Player profile / First-year CS student</p><p class="overview-name">Lopez Aaron Jhon P.</p><p class="overview-description">Relationship status: Single</p><p class="overview-description">From Poblacion, Pangasinan — learning programming and web development, finding inspiration in games, and working toward becoming a game developer.</p></div><div class="overview-progress"><div class="overview-level"><span>Level <strong>18</strong></span><span>CS Apprentice</span></div><div class="overview-xp" role="progressbar" aria-label="Experience toward Junior Developer" aria-valuenow="64" aria-valuemin="0" aria-valuemax="100"><span></span></div><p>640 / 1000 XP <span>Next: Junior Developer</span></p></div>';
grid.before(hint, overview);
function fitPopup() {
  if (!dialog.open) return;
  const viewport = dialog.querySelector('.popup-viewport');
  popupContent.style.transform = 'translate(-50%, -50%)';
  const scale = Math.min(1, (viewport.clientHeight - 24) / popupContent.scrollHeight, (viewport.clientWidth - 24) / popupContent.offsetWidth);
  popupContent.style.transform = `translate(-50%, -50%) scale(${scale})`;
}
function openPopup(id) {
  const entry = popupSections.get(id);
  popupSections.forEach(({ section }) => {
    section.hidden = section !== entry.section;
    section.inert = section !== entry.section;
  });
  dialog.querySelector('#popup-title').textContent = entry.title;
  if (!dialog.open) dialog.showModal();
  fitPopup();
}
dialog.querySelector('.popup-close').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', event => {
  if (event.target === dialog) {
    const bounds = dialog.getBoundingClientRect();
    if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) dialog.close();
  }
});
dialog.addEventListener('close', () => {
  const active = [...popupSections.values()].find(({ section }) => !section.hidden);
  if (active?.card.isConnected) active.card.focus({ preventScroll: true });
});
document.querySelector('.xpbar span').style.width = '64%';
document.querySelector('.lvl-ring circle:last-child').style.strokeDashoffset = String(376.99111843077515 * .36);
const pages = [...main.children].filter(el => el.tagName === 'SECTION');
const previous = document.querySelector('.previous-page');
const next = document.querySelector('.next-page');
const counter = document.querySelector('.page-count');
let current = 0;
function fit() {
  fitPopup();
  const page = pages[current];
  const wrap = page.querySelector(':scope > .wrap');
  const marquee = page.querySelector('.marquee');
  const height = main.clientHeight - (marquee?.offsetHeight || 0) - 24;
  wrap.style.position = 'absolute';
  wrap.style.left = '50%';
  wrap.style.top = `${(main.clientHeight - (marquee?.offsetHeight || 0)) / 2}px`;
  wrap.style.transformOrigin = 'center';
  wrap.style.transform = 'translate(-50%, -50%)';
  const scale = Math.min(1, height / wrap.scrollHeight, main.clientWidth / wrap.offsetWidth);
  wrap.style.transform = `translate(-50%, -50%) scale(${scale})`;
  if (marquee) { marquee.style.position = 'absolute'; marquee.style.bottom = '0'; marquee.style.width = '100%'; }
}
function show(id, focus = false) {
  const target = document.getElementById(id);
  const index = pages.findIndex(page => page === target || page.contains(target));
  current = popupSections.has(id) ? 1 : index < 0 ? 0 : index;
  if (dialog.open) dialog.close();
  pages.forEach((page, i) => { page.hidden = i !== current; page.inert = i !== current; });
  previous.disabled = current === 0;
  next.innerHTML = current === pages.length - 1 ? 'Home <span aria-hidden="true">↑</span>' : 'Next <span aria-hidden="true">→</span>';
  counter.textContent = `${String(current + 1).padStart(2, '0')} / ${String(pages.length).padStart(2, '0')}`;
  document.querySelectorAll('.site-nav a').forEach(link => {
    const target = link.hash.slice(1);
    const active = target === pages[current].id;
    if (active) link.setAttribute('aria-current', 'page'); else link.removeAttribute('aria-current');
  });
  fit();
  if (focus) main.focus({ preventScroll: true });
  if (popupSections.has(id)) openPopup(id);
}
function navigate(index) { location.hash = pages[(index + pages.length) % pages.length].id; }
next.addEventListener('click', () => navigate(current + 1));
previous.addEventListener('click', () => { if (current > 0) navigate(current - 1); });
document.addEventListener('click', event => {
  const link = event.target.closest('a');
  if (!link || !link.hash || !(popupSections.has(link.hash.slice(1)) || pages.some(page => page.id === link.hash.slice(1)))) return;
  event.preventDefault();
  if (location.hash === link.hash) show(link.hash.slice(1), true); else location.hash = link.hash;
});
window.addEventListener('hashchange', () => show(location.hash.slice(1), true));
window.addEventListener('resize', fit);
window.visualViewport?.addEventListener('resize', fit);
document.fonts.ready.then(fit);
document.querySelector('img').addEventListener('load', fit);
document.addEventListener('keydown', event => {
  if (dialog.open || event.target.closest('input, textarea, select, button, a') || event.altKey || event.ctrlKey || event.metaKey) return;
  if (event.key === 'ArrowRight') { event.preventDefault(); navigate(current + 1); }
  if (event.key === 'ArrowLeft' && current > 0) { event.preventDefault(); navigate(current - 1); }
});
const clock = document.querySelector('.clock');
function tick() { clock.textContent = new Date().toLocaleTimeString('en-US', { timeZone: 'Asia/Manila' }) + ' PHT'; }
tick(); setInterval(tick, 1000);
// Quest descriptions and filters retain the original portfolio's behavior.
document.querySelectorAll('.quest').forEach(row => {
  const button = row.querySelector('button');
  const quest = quests.find(item => 'quest-' + item.id === button.getAttribute('aria-controls'));
  let detail = row.querySelector('.qd');
  if (!detail) {
    detail = document.createElement('div'); detail.className = 'qd'; detail.id = 'quest-' + quest.id;
    detail.textContent = quest.detail;
    const reward = document.createElement('span'); reward.className = 'rw'; reward.textContent = 'Reward: ' + quest.reward;
    detail.append(reward); row.append(detail);
  }
  detail.hidden = button.getAttribute('aria-expanded') !== 'true';
  button.addEventListener('click', () => {
    const expand = button.getAttribute('aria-expanded') !== 'true';
    document.querySelectorAll('.quest button').forEach(other => { other.setAttribute('aria-expanded', 'false'); other.nextElementSibling.hidden = true; });
    button.setAttribute('aria-expanded', String(expand)); detail.hidden = !expand; fit();
  });
});
const questFilters = [...document.querySelectorAll('#quests .tab')];
questFilters.forEach((button, index) => button.addEventListener('click', () => {
  questFilters.forEach(tab => tab.setAttribute('aria-pressed', String(tab === button)));
  const status = ['all', 'completed', 'active', 'locked'][index];
  document.querySelectorAll('.quest').forEach(row => { row.hidden = status !== 'all' && row.dataset.status !== status; }); fit();
}));
const slots = [...document.querySelectorAll('button.slot')];
function inspect(index) {
  const item = items[index]; const detail = document.querySelector('.detail');
  slots.forEach((slot, i) => slot.setAttribute('aria-pressed', String(i === index)));
  detail.className = 'detail r-' + item.rarity;
  detail.querySelector('.big').textContent = item.icon;
  detail.querySelector('.rarity').textContent = item.rarity + ' · ' + item.category;
  detail.querySelector('h3').textContent = item.name;
  detail.querySelector('p').textContent = item.description;
  detail.querySelector('.fx').textContent = 'Effect: ' + item.effect; fit();
}
slots.forEach((slot, index) => slot.addEventListener('click', () => inspect(index)));
const inventoryFilters = [...document.querySelectorAll('#inventory .tab')];
inventoryFilters.forEach(button => button.addEventListener('click', () => {
  inventoryFilters.forEach(tab => tab.setAttribute('aria-pressed', String(tab === button)));
  const category = button.textContent;
  slots.forEach((slot, index) => { slot.hidden = category !== 'All' && items[index].category !== category; });
  document.querySelectorAll('.slot.empty').forEach(slot => { slot.hidden = category !== 'All'; });
  inspect(slots.findIndex(slot => !slot.hidden));
}));
const form = document.forms.contact;
const status = form.querySelector('[role=status]');
status.classList.remove('sr-only');
form.addEventListener('submit', event => {
  event.preventDefault();
  status.textContent = 'This downloaded copy cannot send messages. Please use the email link to contact me directly.';
  fit();
});
show(location.hash.slice(1));
